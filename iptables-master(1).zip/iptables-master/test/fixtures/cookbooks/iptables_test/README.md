# iptables_test
This cookbook installs iptables and tests whether the iptables cookbook can add a rule.
