name 'iptables_test'
version '0.0.1'

depends 'iptables'
